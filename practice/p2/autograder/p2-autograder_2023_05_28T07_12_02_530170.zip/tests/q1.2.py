OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': [1, 1, 1, 1, 1],
    'suites': [   {   'cases': [   {   'code': '>>> # Task 1\n'
                                               '>>> assert isinstance(census_summary, pd.DataFrame), "census_summary dataftame is not created"\n'
                                               '>>> assert census_summary.shape == (11, 15), "census_summary shape is incorrect. Probably you are not including all columns"\n'
                                               '>>> assert census_summary.loc[\'min\'][\'age\'] == 17.0, "census_summary dataframe is incorrect"\n'
                                               '>>> assert census_summary.loc[\'top\'][\'occupation\'] == "Prof-specialty", "census_summary dataframe is incorrect"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Task 2\n'
                                               '>>> assert (sha1(str(max_hours_per_week).encode(\'utf8\')).hexdigest() == "3359de52c8ae993fe0f8fe9c5168a0065bd3c7a4"), "max_hours_per_week are '
                                               'incorrect"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Task 3\n'
                                               '>>> assert (sha1(str(most_freq_occupation).encode(\'utf8\')).hexdigest() == "97165f50eddb0d28a382b0366274e2fe38505644"), "most_freq_occupation is '
                                               'incorrect"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Task 4\n'
                                               '>>> assert (sha1(str(missing_vals_cols).encode(\'utf8\')).hexdigest() == "6bc5e13d4d66b306e52701ee9a1e5e21bf19aeb0"), "Please use the exact '
                                               'column/feature name. Also, make sure the lists are sorted."\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Task 5\n'
                                               '>>> assert (sha1(str(numeric_cols).encode(\'utf8\')).hexdigest() == "615afaf5011128d641ab8a73289d57bd01a3ec37"), "Please use the exact column/feature '
                                               'name. Also, make sure the lists are sorted."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
