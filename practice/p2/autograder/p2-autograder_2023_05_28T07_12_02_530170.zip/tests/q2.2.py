OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> assert (sha1(str(numeric_features).encode(\'utf8\')).hexdigest() == "71401cf60034fd69eee7398866359f612adf3e15"), "numeric_features list is not '
                                               'correct"\n'
                                               '>>> assert (sha1(str(categorical_features).encode(\'utf8\')).hexdigest() == "af1a4022c0362405678be5c3a6735578a8c0069f"), "categorical_features list is '
                                               'not correct"\n'
                                               '>>> assert (sha1(str(ordinal_features).encode(\'utf8\')).hexdigest() == "95b86602c44211f3ad662bb58b8e53d024106d05"), "ordinal_features list is not '
                                               'correct"\n'
                                               '>>> assert (sha1(str(binary_features).encode(\'utf8\')).hexdigest() == "d4b7aa4c56ac2f98e6ac9cec7768484b415b7337"), "binary_features list is not '
                                               'correct"\n'
                                               '>>> assert (sha1(str(drop_features).encode(\'utf8\')).hexdigest() == "62aab57d42c54be3dfd3c55020e5a167ca1a84c3"), "drop_features list is not correct"\n'
                                               '>>> assert (sha1(str(target).encode(\'utf8\')).hexdigest() == "0f613350b66e64d92ef21bc4dcdbf8996cb4edf0"), "target variable is not set correctly"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
