OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not X_train is None, "Your answer does not exist. Have you passed in the correct variable?"\n'
                                               '>>> assert not y_train is None, "Your answer does not exist. Have you passed in the correct variable?"\n'
                                               '>>> assert not X_test is None, "Your answer does not exist. Have you passed in the correct variable?"\n'
                                               '>>> assert not y_test is None, "Your answer does not exist. Have you passed in the correct variable?"\n'
                                               '>>> assert X_train.shape == (13024, 14), "The dimensions of X_train are incorrect"\n'
                                               '>>> assert y_train.shape == (13024, ), "The dimensions of y_train are incorrect. Are you splitting correctly"\n'
                                               '>>> assert X_test.shape == (19537,14), "The dimensions of X_test are incorrect. Are you splitting correctly? Are you using single brackets?"\n'
                                               '>>> assert y_test.shape == (19537,), "The dimensions of y_test are incorrect. Are you splitting correctly? Are you using single brackets?"\n'
                                               '>>> assert \'income\' not in list(X_train.columns), "Make sure the target variable is not part of your X dataset."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
