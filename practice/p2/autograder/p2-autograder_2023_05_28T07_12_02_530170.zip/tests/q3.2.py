OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not dummy_df is None, "Have you used the correct variable to store the results?"\n'
                                               '>>> assert sorted(list(dummy_df.columns)) == [\'fit_time\',\'score_time\',\'test_score\',\'train_score\'], "Your solution contains incorrect '
                                               'columns."\n'
                                               '>>> assert dummy_df.shape == (5,4), "Are you carrying out 5-fold cross-validation and are you passing return_train_score=True?"\n'
                                               '>>> assert np.isclose(round(dummy_df[\'test_score\'].mean(),3), 0.758), "The test scores seem wrong. Are you calling the cross_validate correctly?"\n'
                                               '>>> assert np.isclose(round(dummy_df[\'train_score\'].mean(),3), 0.758), "The train scores seem wrong. Are you calling the cross_validate '
                                               'correctly?"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
