OK_FORMAT = True

test = {   'name': 'q4.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not binary_transformer is None, "Are you using the correct variable name?"\n'
                                               '>>> assert binary_transformer.get_params()[\'drop\'] == \'if_binary\', "Are you passing `drop=if_binary`?"\n'
                                               '>>> assert binary_transformer.get_params()[\'dtype\'] == int, "Please set the dtype to int"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
