OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not train_df is None and not test_df is None, "Please use the provided variables."\n'
                                               '>>> assert train_df.shape == (13024, 15), "The dimensions of the training set are incorrect"\n'
                                               '>>> assert test_df.shape == (19537, 15), "The dimensions of the test set are incorrect"\n'
                                               ">>> assert train_df.loc[12846][['age', 'education', 'occupation', 'capital.loss']].tolist() == [49, 'Some-college', 'Craft-repair', 0], "
                                               '"Are you using the provided random state?"\n'
                                               ">>> assert not 20713 in train_df.index, 'Are you using the provided random state?' \n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
