OK_FORMAT = True

test = {   'name': 'q4.4',
    'points': [5, 1, 1],
    'suites': [   {   'cases': [   {   'code': '>>> # task 1\n'
                                               '>>> assert not preprocessor is None, "Are you using the correct variable name?"\n'
                                               '>>> assert len(preprocessor.get_params()[\'transformers\']) in range(4,6,1), "Have you included all the transformers?"\n'
                                               ">>> assert 'onehotencoder' in preprocessor.get_params().keys(), 'Either the categorical_transformer or binary_transformer is not included.'\n"
                                               ">>> assert 'standardscaler' in preprocessor.get_params().keys(), 'numeric_transformer is not included.'\n"
                                               ">>> assert 'ordinalencoder' in preprocessor.get_params().keys(), 'ordinal_transformer is not included.'\n"
                                               ">>> assert 'drop' in preprocessor.get_params().keys(), 'drop features step is not included.'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # task 2\n'
                                               '>>> assert not transformed_df is None, "Are you using the correct variable name?"\n'
                                               '>>> assert sha1(str(transformed_df.shape).encode(\'utf8\')).hexdigest() == \'a0521f0cdbcd77cd213e7d1a3cfc13c1c7c92a6e\', "The shape of the transformed '
                                               'data is incorrect."\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert sha1(str(n_new_cols).encode(\'utf8\')).hexdigest() == \'b7103ca278a75cad8f7d065acda0c2e80da0b7dc\', "The number of new columns (n_new_cols) '
                                               'is incorrect."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
