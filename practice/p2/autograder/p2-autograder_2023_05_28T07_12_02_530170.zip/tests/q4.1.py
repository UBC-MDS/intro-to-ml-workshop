OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> assert not ordinal_transformer is None, "Are you using the correct variable name?"\n'
                                               '>>> assert type(ordinal_transformer.get_params()[\'categories\'][0]) is list, "Are you passing education levels as a list of lists?"\n'
                                               '>>> assert ordinal_transformer.get_params()[\'dtype\'] == int, "Please set the dtype to int"\n'
                                               '>>> assert (sha1(str(ordinal_transformer.get_params()[\'categories\'][0]).encode(\'utf8\')).hexdigest() == "893a03d114b2af09b53247866c6eea54ebfd090f") '
                                               'or (sha1(str(ordinal_transformer.get_params()[\'categories\'][0]).encode(\'utf8\')).hexdigest() == "81059b8bebc9ddb03d61bf07cfd9b9b6b0da288e"), "Make '
                                               'sure you are passing categories sorted on levels of education. (Ascending or descending shouldn\'t matter.)"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
