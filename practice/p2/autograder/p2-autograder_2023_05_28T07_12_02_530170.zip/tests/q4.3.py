OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.pipeline import Pipeline\n'
                                               '>>> assert not categorical_transformer is None, "Are you using the correct variable name?"\n'
                                               '>>> assert type(categorical_transformer) is Pipeline, "Are you creating a scikit-learn Pipeline?"\n'
                                               '>>> assert len(categorical_transformer.get_params()[\'steps\']) == 2, "Are you creating a pipeline with two steps?"\n'
                                               '>>> assert categorical_transformer.get_params()[\'simpleimputer__strategy\'] == \'constant\', "Are you passing strategy=constant in the '
                                               'SimpleImputer?"\n'
                                               '>>> assert categorical_transformer.get_params()[\'simpleimputer__fill_value\'] == \'missing\', "Are you passing fill_value=\'missing\' in the '
                                               'SimpleImputer?"\n'
                                               '>>> assert categorical_transformer.get_params()[\'onehotencoder__handle_unknown\'] == \'ignore\', "Are you passing handle_unknown = \'ignore\' '
                                               'argument to your OHE?"\n'
                                               '>>> assert categorical_transformer.get_params()[\'onehotencoder__sparse_output\'] == False, "Are you creating a sparase matrix for OHE?"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
