OK_FORMAT = True

test = {   'name': 'q4.1',
    'points': [1, 2, 2, 2, 5],
    'suites': [   {   'cases': [   {   'code': '>>> assert X_train.shape == (1613, 7), "Shape is incorrect"\n'
                                               '>>> assert y_train.shape == (1613,), "Shape is incorrect"\n'
                                               '>>> assert X_test.shape == (404, 7), "Shape is incorrect"\n'
                                               '>>> assert y_test.shape == (404,), "Shape is incorrect"\n'
                                               '>>> \n'
                                               '>>> assert (round(X_train.iloc[123]["loudness"], 2) == -10.10), "Are you using the correct X_train, y_train, X_test, y_test?"\n'
                                               '>>> assert (round(y_train.iloc[62], 2) == 0.00), "Are you using the correct X_train, y_train, X_test, y_test?"\n'
                                               '>>> assert (round(X_test.iloc[234]["valence"], 2) == 0.18), "Are you using the correct X_train, y_train, X_test, y_test?"\n'
                                               '>>> assert (round(y_test.iloc[399], 2) == 1.00), "Are you using the correct X_train, y_train, X_test, y_test?"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert not max_depth_plot is None, "Are you storing the plot in a variable?"\n'
                                               '>>> assert (len(max_depth_plot.lines) == 2), "Please plot both the train accuracy and the cross-validation accuracy"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check if the expected max_depths are on the x-axis\n'
                                               '>>> assert "depth" in max_depth_plot.get_xlabel().lower(), "Please give x-axis a reasonable name"\n'
                                               '>>> assert "accuracy" in max_depth_plot.get_ylabel().lower(), "Please give y-axis a reasonable name"\n'
                                               '>>> assert (max_depth_plot.lines[0].get_xdata() == np.arange(1, 25, 2)).all(), "Please use the provided max_depth values"\n'
                                               '>>> assert len(max_depth_plot.lines[1].get_xdata()) == len(np.arange(1, 25, 2)), "Please use the provided max_depth values"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Check if the curves are labeled with reasonable names\n'
                                               '>>> assert any(label in max_depth_plot.legend().get_texts()[0].get_text().lower() for label in ["train", "test", "cv"]), "Please label your curves '
                                               'with reasonable names"\n'
                                               '>>> assert any(label in max_depth_plot.legend().get_texts()[1].get_text().lower().lower() for label in ["train", "test", "cv"]), "Please label your '
                                               'curves with reasonable names"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Get train and test data points\n'
                                               '>>> legend_texts = max_depth_plot.legend().get_texts()\n'
                                               '>>> if "train" in legend_texts[0].get_text():\n'
                                               '...     train_xydata = max_depth_plot.lines[0].get_xydata()\n'
                                               '...     valid_xydata = max_depth_plot.lines[1].get_xydata()\n'
                                               '... else:\n'
                                               '...     train_xydata = max_depth_plot.lines[1].get_xydata()\n'
                                               '...     valid_xydata = max_depth_plot.lines[0].get_xydata()\n'
                                               '>>> \n'
                                               '>>> # Training scores should increase when max_depth increases\n'
                                               '>>> assert np.isclose(round(train_xydata[2][1], 3), 0.728, atol=0.02), "The training data points are incorrect"\n'
                                               '>>> assert (train_xydata[6][1] >= train_xydata[2][1]), "The training data points are incorrect"\n'
                                               '>>> assert (train_xydata[10][1] >= train_xydata[6][1]), "The training data points are incorrect"\n'
                                               '>>> \n'
                                               '>>> # Test scores\n'
                                               '>>> assert np.isclose(round(valid_xydata[2][1], 3), 0.654, atol=0.02), "The training data points are incorrect"\n'
                                               '>>> assert np.isclose(round(valid_xydata[6][1], 3), 0.632, atol=0.02), "The training data points are incorrect"\n'
                                               '>>> assert np.isclose(round(valid_xydata[10][1], 3), 0.634, atol=0.02), "The training data points are incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
