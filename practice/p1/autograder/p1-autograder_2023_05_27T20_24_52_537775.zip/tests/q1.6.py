OK_FORMAT = True

test = {   'name': 'q1.6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert not toy_depth is None, "Are you using the provided variable?"\n'
                                               '>>> assert (sha1(str(toy_depth).encode("utf-8")).hexdigest() == "77de68daecd823babbb58edb1c8e14d7106e83bb"), "The depth is incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
