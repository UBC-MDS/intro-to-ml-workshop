OK_FORMAT = True

test = {   'name': 'q3.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(X_train, pd.DataFrame), "X_train is not created correctly"\n'
                                               '>>> assert isinstance(y_train, pd.Series), "y_train is not created correctly"\n'
                                               '>>> assert isinstance(X_test, pd.DataFrame), "X_test is not created correctly"\n'
                                               '>>> assert isinstance(y_test, pd.Series), "y_test is not created correctly"\n'
                                               '>>> assert X_train.shape == (1613, 7), "X_train has the wrong shape"\n'
                                               '>>> assert X_test.shape == (404, 7), "X_test has the wrong shape"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
