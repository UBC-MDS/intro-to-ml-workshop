OK_FORMAT = True

test = {   'name': 'q3.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(spotify_tree, DecisionTreeClassifier), "DecisionTreeClassifier was not created properly"\n'
                                               '>>> assert (spotify_tree.get_params().get("random_state") == 123), "Please set the random state to 123"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
