OK_FORMAT = True

test = {   'name': 'q4.5',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not best_feat is None, "Are you setting the best_feat variable?"\n'
                                               '>>> assert sha1(best_feat.encode(\'utf-8\')).hexdigest() == \'6cd560e4ccffc46287399c5f226bb2cc95e8c987\', "The best_feat seems incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
