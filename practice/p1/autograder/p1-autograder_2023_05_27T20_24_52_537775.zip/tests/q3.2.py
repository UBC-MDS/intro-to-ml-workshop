OK_FORMAT = True

test = {   'name': 'q3.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not dummy_scores is None, "Are you using the provided variable?"\n'
                                               '>>> assert(dummy_scores.shape[0] == 10)\n'
                                               '>>> \n'
                                               '>>> dummy2 = DummyClassifier()\n'
                                               '>>> dummy_scores2 = pd.DataFrame(cross_validate(dummy2, X_train, y_train, cv=10, return_train_score=True))\n'
                                               ">>> assert(dummy_scores['test_score'].mean() == dummy_scores2['test_score'].mean())\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
