OK_FORMAT = True

test = {   'name': 'q1.9',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not predictions is None, "Are you storing predictions in the provided variable predictions?"\n'
                                               '>>> assert (predictions == toy_tree.predict(offer_df)).all(), "Your predictions do not look as expected."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
