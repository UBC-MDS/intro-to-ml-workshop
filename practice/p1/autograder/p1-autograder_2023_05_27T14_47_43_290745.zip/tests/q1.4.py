OK_FORMAT = True

test = {   'name': 'q1.4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert toy_tree.get_depth() in range(2, 4, 1), "DecisionTreeClassifier was not fitted properly"\n'
                                               '>>> assert toy_tree.get_n_leaves() in range(3, 5, 1), "DecisionTreeClassifier was not fitted properly"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
