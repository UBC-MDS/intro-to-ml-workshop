OK_FORMAT = True

test = {   'name': 'q4.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not best_max_depth is None, "Are you using the provided variable?"\n'
                                               '>>> assert sha1(str(best_max_depth).encode(\'utf-8\')).hexdigest() == \'ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4\', "Are you picking the '
                                               'best_max_depth which gives the highest cross-validation score?"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
