OK_FORMAT = True

test = {   'name': 'q4.4',
    'points': [2, 1],
    'suites': [   {   'cases': [   {   'code': '>>> assert not best_model is None, "Are you creating a tree called best_spotify_tree?"\n'
                                               '>>> assert best_model.get_params()[\'random_state\'] == 123, "Are you setting the random_state to 123?"\n'
                                               '>>> assert best_model.get_n_leaves() in range(25, 30), "Are you fitting best_spotify_tree?"\n'
                                               '>>> assert best_model.get_depth() == best_max_depth, "Are you fitting best_spotify_tree?"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert (round(test_score, 3) == 0.661), "Your test score seems off. Are you training on the entire training data?"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
