OK_FORMAT = True

test = {   'name': 'q1.5',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert not toy_tree_viz is None, "Are you using the provided variable?"\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
