OK_FORMAT = True

test = {   'name': 'q1.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(toy_tree, DecisionTreeClassifier), "DecisionTreeClassifier was not created properly"\n'
                                               '>>> assert (toy_tree.get_params().get("random_state") == 16), "Please set the random state to 16"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
