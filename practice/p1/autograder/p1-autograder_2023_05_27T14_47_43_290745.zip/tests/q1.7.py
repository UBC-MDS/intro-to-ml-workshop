OK_FORMAT = True

test = {   'name': 'q1.7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert not train_acc is None, "Are you using the provided train_acc variable?"\n'
                                               '>>> assert (sha1(str(np.round(train_acc, 2)).encode("utf-8")).hexdigest() == "1469842b4307d36cccb487dc989f21016daadbcc"), "The score is incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
