OK_FORMAT = True

test = {   'name': 'q3.4',
    'points': [1, 1, 2],
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(dt_scores_df, pd.DataFrame), "dt_scores_df should be a DataFrame"\n'
                                               '>>> assert len(dt_scores_df) == 10, "Please check parameters of `cross_validate`"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert dt_scores_df.shape[0] == 10, "Are you carrying out 10-fold cross-validation?"\n'
                                               '>>> assert dt_scores_df.shape[1] == 4, "Are you passing return_train_scores = True?"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(round(dt_scores_df["test_score"].mean(), 3), 0.634), "Your test scores are incorrect"\n'
                                               '>>> assert np.isclose(round(dt_scores_df["train_score"].mean(), 3), 0.999), "Your train scores are incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
