OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not supportive_colleagues_acc is None, "Are you setting the provided variable?"\n'
                                               '>>> assert (\n'
                                               '...     sha1(str(supportive_colleagues_acc).encode("utf8")).hexdigest() == "1469842b4307d36cccb487dc989f21016daadbcc"), "Your answer is incorrect, see '
                                               'traceback above."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
