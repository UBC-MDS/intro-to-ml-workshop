OK_FORMAT = True

test = {   'name': 'q2.2',
    'points': [1, 1],
    'suites': [   {   'cases': [   {   'code': '>>> assert (not train_df is None and not test_df is None), "Are you using the provided variables?"\n'
                                               '>>> n_total_samples = spotify_df.shape[0]\n'
                                               '>>> assert test_df.shape[0] == round(n_total_samples * 0.2) + (n_total_samples % 5 > 0), "Are you using the provided test size?"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(train_df.iloc[30]["liveness"], 0.268), "Are you using the provided random state?"\n'
                                               '>>> assert np.isclose(test_df.iloc[88]["danceability"], 0.727), "Are you using the provided random state?"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
