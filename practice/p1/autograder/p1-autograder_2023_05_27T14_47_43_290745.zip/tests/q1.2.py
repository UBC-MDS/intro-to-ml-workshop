OK_FORMAT = True

test = {   'name': 'q1.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert not X_train_toy is None, "Are you using the correct variable?"\n'
                                               '>>> assert not y_train_toy is None, "Are you using the correct variable?"\n'
                                               '>>> assert X_train_toy.shape == (10, 3), "X_train_toy shape is incorrect"\n'
                                               '>>> assert y_train_toy.shape == (10,), "y_train_toy shape is incorrect"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
